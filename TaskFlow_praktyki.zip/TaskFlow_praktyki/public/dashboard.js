let allTasks = [];
let currentFilter = "all";

async function requireLogin() {
    const response = await fetch("/api/me");

    if (!response.ok) {
        window.location.href = "/";
        return null;
    }

    const data = await response.json();
    document.getElementById("welcome-title").textContent = `Cześć, ${data.user.username}!`;
    return data.user;
}

async function loadTasks() {
    const response = await fetch("/api/tasks");

    if (!response.ok) {
        if (response.status === 401) {
            window.location.href = "/";
        }
        return;
    }

    allTasks = await response.json();
    renderTasks();
}

async function loadStats() {
    const response = await fetch("/api/stats");
    if (!response.ok) return;

    const stats = await response.json();

    document.getElementById("stat-total").textContent = stats.total;
    document.getElementById("stat-remaining").textContent = stats.remaining;
    document.getElementById("stat-done").textContent = stats.done;
    document.getElementById("stat-high").textContent = stats.highPriority;
}

function getPriorityClass(priority) {
    if (priority === "Wysoki") return "high";
    if (priority === "Niski") return "low";
    return "";
}

function renderTasks() {
    const list = document.getElementById("task-list");
    const empty = document.getElementById("empty-state");
    const search = document.getElementById("search-input").value.trim().toLowerCase();

    let tasks = [...allTasks];

    if (currentFilter === "open") {
        tasks = tasks.filter(task => !task.completed);
    }

    if (currentFilter === "done") {
        tasks = tasks.filter(task => task.completed);
    }

    if (search) {
        tasks = tasks.filter(task =>
            task.title.toLowerCase().includes(search) ||
            task.description.toLowerCase().includes(search) ||
            task.category.toLowerCase().includes(search)
        );
    }

    list.innerHTML = "";

    if (!tasks.length) {
        empty.classList.remove("hidden");
        return;
    }

    empty.classList.add("hidden");

    tasks.forEach(task => {
        const card = document.createElement("article");
        card.className = `task-card ${task.completed ? "completed" : ""}`;

        const dueText = task.due_date
            ? new Date(task.due_date + "T00:00:00").toLocaleDateString("pl-PL")
            : "Bez terminu";

        card.innerHTML = `
            <button class="check-button" data-action="toggle" data-id="${task.id}">
                ${task.completed ? "✓" : ""}
            </button>

            <div>
                <h3 class="task-title">${escapeHtml(task.title)}</h3>
                <p class="task-desc">${escapeHtml(task.description || "Brak dodatkowego opisu.")}</p>

                <div class="task-meta">
                    <span class="badge">${escapeHtml(task.category)}</span>
                    <span class="badge ${getPriorityClass(task.priority)}">${escapeHtml(task.priority)} priorytet</span>
                    <span class="badge">${dueText}</span>
                </div>
            </div>

            <button class="delete-button" data-action="delete" data-id="${task.id}" title="Usuń">×</button>
        `;

        list.appendChild(card);
    });
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

document.getElementById("task-form").addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = document.getElementById("task-message");
    message.textContent = "Dodawanie...";

    const response = await fetch("/api/tasks", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            title: document.getElementById("task-title").value,
            description: document.getElementById("task-description").value,
            category: document.getElementById("task-category").value,
            priority: document.getElementById("task-priority").value,
            due_date: document.getElementById("task-due-date").value
        })
    });

    const data = await response.json();

    if (!response.ok) {
        message.textContent = data.error || "Nie udało się dodać zadania.";
        return;
    }

    message.style.color = "#38d39f";
    message.textContent = "Zadanie dodane.";

    event.target.reset();

    setTimeout(() => {
        message.textContent = "";
        message.style.color = "";
    }, 1400);

    await Promise.all([loadTasks(), loadStats()]);
});

document.getElementById("task-list").addEventListener("click", async (event) => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const id = button.dataset.id;
    const action = button.dataset.action;

    if (action === "toggle") {
        await fetch(`/api/tasks/${id}/toggle`, {
            method: "PATCH"
        });
    }

    if (action === "delete") {
        const confirmed = confirm("Na pewno usunąć to zadanie?");
        if (!confirmed) return;

        await fetch(`/api/tasks/${id}`, {
            method: "DELETE"
        });
    }

    await Promise.all([loadTasks(), loadStats()]);
});

document.getElementById("search-input").addEventListener("input", renderTasks);

function setFilter(filter, title, button) {
    currentFilter = filter;
    document.getElementById("list-title").textContent = title;

    document.querySelectorAll(".nav-item").forEach(item => {
        item.classList.remove("active");
    });

    button.classList.add("active");
    renderTasks();
}

document.querySelector(".nav-item.active").addEventListener("click", function () {
    setFilter("all", "Lista zadań", this);
});

document.getElementById("show-all").addEventListener("click", function () {
    setFilter("all", "Wszystkie zadania", this);
});

document.getElementById("show-open").addEventListener("click", function () {
    setFilter("open", "Do zrobienia", this);
});

document.getElementById("show-done").addEventListener("click", function () {
    setFilter("done", "Ukończone", this);
});

document.getElementById("logout-button").addEventListener("click", async () => {
    await fetch("/api/logout", {
        method: "POST"
    });

    window.location.href = "/";
});

const themeButton = document.getElementById("theme-toggle");

function applySavedTheme() {
    const savedTheme = localStorage.getItem("taskflow-theme");

    if (savedTheme === "light") {
        document.body.classList.add("light");
        themeButton.textContent = "☀";
    }
}

themeButton.addEventListener("click", () => {
    document.body.classList.toggle("light");

    const light = document.body.classList.contains("light");
    themeButton.textContent = light ? "☀" : "☾";
    localStorage.setItem("taskflow-theme", light ? "light" : "dark");
});

(async function init() {
    applySavedTheme();
    await requireLogin();
    await Promise.all([loadTasks(), loadStats()]);
})();
