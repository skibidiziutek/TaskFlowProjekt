const tabs = document.querySelectorAll(".tab");
const forms = document.querySelectorAll(".auth-form");

tabs.forEach(tab => {
    tab.addEventListener("click", () => {
        tabs.forEach(t => t.classList.remove("active"));
        forms.forEach(form => form.classList.remove("active"));

        tab.classList.add("active");
        document.getElementById(tab.dataset.target).classList.add("active");
    });
});

async function checkSession() {
    const response = await fetch("/api/me");
    if (response.ok) {
        window.location.href = "/dashboard.html";
    }
}

checkSession();

document.getElementById("register-form").addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = document.getElementById("register-message");
    message.textContent = "Tworzenie konta...";

    const response = await fetch("/api/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            username: document.getElementById("register-username").value,
            email: document.getElementById("register-email").value,
            password: document.getElementById("register-password").value
        })
    });

    const data = await response.json();

    if (!response.ok) {
        message.textContent = data.error || "Nie udało się utworzyć konta.";
        return;
    }

    message.style.color = "#38d39f";
    message.textContent = "Konto utworzone!";

    setTimeout(() => {
        window.location.href = "/dashboard.html";
    }, 500);
});

document.getElementById("login-form").addEventListener("submit", async (event) => {
    event.preventDefault();

    const message = document.getElementById("login-message");
    message.textContent = "Logowanie...";

    const response = await fetch("/api/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            email: document.getElementById("login-email").value,
            password: document.getElementById("login-password").value
        })
    });

    const data = await response.json();

    if (!response.ok) {
        message.textContent = data.error || "Nie udało się zalogować.";
        return;
    }

    message.style.color = "#38d39f";
    message.textContent = "Zalogowano!";

    setTimeout(() => {
        window.location.href = "/dashboard.html";
    }, 400);
});
