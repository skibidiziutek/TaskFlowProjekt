const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const PORT = 3000;
const db = new Database("taskflow.db");

db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT DEFAULT '',
    category TEXT DEFAULT 'Inne',
    priority TEXT DEFAULT 'Średni',
    due_date TEXT DEFAULT '',
    completed INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: "taskflow-school-project-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 1000 * 60 * 60 * 24
    }
}));

app.use(express.static(path.join(__dirname, "public")));

function requireAuth(req, res, next) {
    if (!req.session.userId) {
        return res.status(401).json({ error: "Musisz być zalogowany." });
    }
    next();
}

app.post("/api/register", async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ error: "Uzupełnij wszystkie pola." });
    }

    if (username.length < 3) {
        return res.status(400).json({ error: "Nazwa użytkownika musi mieć minimum 3 znaki." });
    }

    if (password.length < 6) {
        return res.status(400).json({ error: "Hasło musi mieć minimum 6 znaków." });
    }

    try {
        const hash = await bcrypt.hash(password, 10);

        const result = db.prepare(`
            INSERT INTO users (username, email, password)
            VALUES (?, ?, ?)
        `).run(username.trim(), email.trim().toLowerCase(), hash);

        req.session.userId = result.lastInsertRowid;
        req.session.username = username.trim();

        res.json({
            success: true,
            user: {
                id: result.lastInsertRowid,
                username: username.trim(),
                email: email.trim().toLowerCase()
            }
        });
    } catch (err) {
        if (String(err.message).includes("UNIQUE")) {
            return res.status(409).json({ error: "Taka nazwa użytkownika lub e-mail już istnieje." });
        }

        console.error(err);
        res.status(500).json({ error: "Błąd serwera podczas rejestracji." });
    }
});

app.post("/api/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ error: "Podaj e-mail i hasło." });
    }

    const user = db.prepare(`
        SELECT * FROM users WHERE email = ?
    `).get(email.trim().toLowerCase());

    if (!user) {
        return res.status(401).json({ error: "Nieprawidłowy e-mail lub hasło." });
    }

    const validPassword = await bcrypt.compare(password, user.password);

    if (!validPassword) {
        return res.status(401).json({ error: "Nieprawidłowy e-mail lub hasło." });
    }

    req.session.userId = user.id;
    req.session.username = user.username;

    res.json({
        success: true,
        user: {
            id: user.id,
            username: user.username,
            email: user.email
        }
    });
});

app.post("/api/logout", (req, res) => {
    req.session.destroy(() => {
        res.json({ success: true });
    });
});

app.get("/api/me", (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ loggedIn: false });
    }

    const user = db.prepare(`
        SELECT id, username, email, created_at
        FROM users
        WHERE id = ?
    `).get(req.session.userId);

    res.json({
        loggedIn: true,
        user
    });
});

app.get("/api/tasks", requireAuth, (req, res) => {
    const tasks = db.prepare(`
        SELECT *
        FROM tasks
        WHERE user_id = ?
        ORDER BY completed ASC,
                 CASE priority
                    WHEN 'Wysoki' THEN 1
                    WHEN 'Średni' THEN 2
                    ELSE 3
                 END ASC,
                 created_at DESC
    `).all(req.session.userId);

    res.json(tasks);
});

app.post("/api/tasks", requireAuth, (req, res) => {
    const {
        title,
        description = "",
        category = "Inne",
        priority = "Średni",
        due_date = ""
    } = req.body;

    if (!title || !title.trim()) {
        return res.status(400).json({ error: "Tytuł zadania jest wymagany." });
    }

    const result = db.prepare(`
        INSERT INTO tasks (
            user_id,
            title,
            description,
            category,
            priority,
            due_date
        )
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(
        req.session.userId,
        title.trim(),
        description.trim(),
        category,
        priority,
        due_date
    );

    const task = db.prepare(`
        SELECT * FROM tasks WHERE id = ?
    `).get(result.lastInsertRowid);

    res.json(task);
});

app.patch("/api/tasks/:id/toggle", requireAuth, (req, res) => {
    const task = db.prepare(`
        SELECT * FROM tasks
        WHERE id = ? AND user_id = ?
    `).get(req.params.id, req.session.userId);

    if (!task) {
        return res.status(404).json({ error: "Nie znaleziono zadania." });
    }

    const newValue = task.completed ? 0 : 1;

    db.prepare(`
        UPDATE tasks
        SET completed = ?
        WHERE id = ? AND user_id = ?
    `).run(newValue, req.params.id, req.session.userId);

    res.json({ success: true, completed: newValue });
});

app.delete("/api/tasks/:id", requireAuth, (req, res) => {
    const result = db.prepare(`
        DELETE FROM tasks
        WHERE id = ? AND user_id = ?
    `).run(req.params.id, req.session.userId);

    if (!result.changes) {
        return res.status(404).json({ error: "Nie znaleziono zadania." });
    }

    res.json({ success: true });
});

app.get("/api/stats", requireAuth, (req, res) => {
    const total = db.prepare(`
        SELECT COUNT(*) AS count
        FROM tasks
        WHERE user_id = ?
    `).get(req.session.userId).count;

    const done = db.prepare(`
        SELECT COUNT(*) AS count
        FROM tasks
        WHERE user_id = ? AND completed = 1
    `).get(req.session.userId).count;

    const highPriority = db.prepare(`
        SELECT COUNT(*) AS count
        FROM tasks
        WHERE user_id = ?
        AND completed = 0
        AND priority = 'Wysoki'
    `).get(req.session.userId).count;

    res.json({
        total,
        done,
        remaining: total - done,
        highPriority
    });
});

app.listen(PORT, () => {
    console.log(`TaskFlow działa na http://localhost:${PORT}`);
});
